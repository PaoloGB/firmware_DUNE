#!/bin/sh
CDS_CONCEPT_HDL=TRUE;export CDS_CONCEPT_HDL
cd /projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/www/Docs
netassembler
concept2cm -forward -export -proj "/projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/www/Docs/ttc_fmc.cpm"
pxl.exe -proj "/projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/www/Docs/ttc_fmc.cpm" -nosavehier
