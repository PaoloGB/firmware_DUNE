#!/bin/sh
CDS_CONCEPT_HDL=TRUE;export CDS_CONCEPT_HDL
cd /projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/design_files
netassembler
concept2cm -forward -export -proj "/projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/design_files/pc053a_toplevel.cpm"
pxl.exe -proj "/projects/HEP_Instrumentation/cad/designs/uob-hep-pc053a/trunk/design_files/pc053a_toplevel.cpm" -nosavehier
